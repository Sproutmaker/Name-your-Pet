package com.example.namemypet;

public class FillArray {
    //public String[] array = new String[51];
    FillArray(String[] array) {
        array = new String[51];
        array[0] = "Bubbles";
        array[1] = "Kevin";
        array[2] = "Yoda";
        array[3] = "Bella";
        array[4] = "Mo";
        array[5] = "Tina";
        array[6] = "Bear";
        array[7] = "Kodak";
        array[8] = "Max (Short for Maximillian)";
        array[9] = "Nando";
        array[10] = "Chicken";
        array[11] = "Jenga";
        array[12] = "Violet";
        array[13] = "Dobby";
        array[14] = "Mittens";
        array[15] = "Molly";
        array[16] = "Mochi";
        array[17] = "Tinkerbell";
        array[18] = "Mazie";
        array[19] = "JoJo";
        array[20] = "Hank";
        array[21] = "Duke";
        array[22] = "Buddy";
        array[23] = "Cooper";
        array[24] = "Beau";
        array[25] = "Blue";
        array[26] = "Rex";
        array[27] = "Yoshi";
        array[28] = "Boomer";
        array[29] = "Eddy";
        array[30] = "Jerry";
        array[41] = "Lassie";
        array[42] = "Pumpkin";
        array[43] = "Clover";
        array[44] = "Charlie";
        array[45] = "Hunter";
        array[46] = "Link";
        array[47] = "Kirby";
        array[48] = "Bowser";
        array[49] = "Misty";
        array[50] = "Minnie";
    }
}
