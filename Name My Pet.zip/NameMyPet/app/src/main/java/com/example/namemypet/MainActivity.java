package com.example.namemypet;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.provider.MediaStore;
import java.util.Random;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static int RESULT_LOAD_IMAGE = 1;
    Button generateName;
    ImageView animalPhoto;
    TextView nameView;
    private String[] names = new String[51];
    //FillArray(names);
    Random rand = new Random();
    //int indext = rand.nextInt(49);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        animalPhoto = findViewById(R.id.animalPhoto);
        generateName = findViewById(R.id.generateButton);
        nameView = findViewById(R.id.nameView);

        animalPhoto.setOnClickListener(this);
        generateName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int indext = rand.nextInt(51);
                names[0] = "Bubbles";
                names[1] = "Kevin";
                names[2] = "Yoda";
                names[3] = "Bella";
                names[4] = "Mo";
                names[5] = "Tina";
                names[6] = "Bear";
                names[7] = "Kodak";
                names[8] = "Max (Short for Maximillian)";
                names[9] = "Nando";
                names[10] = "Chicken";
                names[11] = "Jenga";
                names[12] = "Violet";
                names[13] = "Dobby";
                names[14] = "Mittens";
                names[15] = "Molly";
                names[16] = "Mochi";
                names[17] = "Tinkerbell";
                names[18] = "Mazie";
                names[19] = "JoJo";
                names[20] = "Hank";
                names[21] = "Duke";
                names[22] = "Buddy";
                names[23] = "Cooper";
                names[24] = "Beau";
                names[25] = "Blue";
                names[26] = "Rex";
                names[27] = "Yoshi";
                names[28] = "Boomer";
                names[29] = "Eddy";
                names[30] = "Jerry";
                names[31] = "Lucky";
                names[32] = "Geoff";
                names[33] = "Gertrude";
                names[34] = "Munchkin";
                names[35] = "Bessie";
                names[36] = "Frankfurt";
                names[37] = "Mocha";
                names[38] = "Ginger";
                names[39] = "Stitch";
                names[40] = "Fin";
                names[41] = "Lassie";
                names[42] = "Pumpkin";
                names[43] = "Clover";
                names[44] = "Charlie";
                names[45] = "Hunter";
                names[46] = "Link";
                names[47] = "Kirby";
                names[48] = "Bowser";
                names[49] = "Misty";
                names[50] = "Minnie";
                nameView.setText(names[indext]);
            }
        });
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.animalPhoto:
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);
                break;
        }
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri selctedImage = data.getData();
            animalPhoto.setImageURI(selctedImage);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}


























