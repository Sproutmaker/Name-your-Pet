import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Base64;
import android.util.Pair;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import java.io.ByteArrayOutputStream;
//import java.net.HttpCookie;
import java.util.ArrayList;

public class UploadPhoto extends AsyncTask<Void, Void, Void> {
    Bitmap image;
    String name;

    public void uploadImage(Bitmap image, String name) {
        this.image = image;
        this.name = name;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        String encodedImage = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);

        ArrayList<Pair> dataToSend = new ArrayList<>();
        dataToSend.add(new Pair("image", encodedImage));
        dataToSend.add(new Pair("name", name));

        HttpParams httpParams = getHttpRequestParams();
        HttpClient client = new DefaultHttpClient(httpParams);
        HttpPost post = new HttpPost();


        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }

    private HttpParams getHttpRequestParams() {
        HttpParams httpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, 1000 * 30); //timeout after 30 seconds
        HttpConnectionParams.setConnectionTimeout(httpParams, 1000 * 30);
        return httpParams;

    }
}
                                                                                                              